package com.example.mypetapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;

//public class MainActivity extends AppCompatActivity {
//
//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_main);
//
//        // 跳转到个人页面
//        findViewById(R.id.btnPersonal).setOnClickListener(v -> {
//            startActivity(new Intent(MainActivity.this, PersonalActivity.class));
//        });
//
//        // 跳转到宠物挑选页面
//        findViewById(R.id.btnPetSelection).setOnClickListener(v -> {
//            startActivity(new Intent(MainActivity.this, PetSelectionActivity.class));
//        });
//
//        // 跳转到我的宠物页面
//        findViewById(R.id.btnMyPets).setOnClickListener(v -> {
//            startActivity(new Intent(MainActivity.this, MypetsActivity.class));
//        });
//    }
//}
// MainActivity.java
public class MainActivity extends AppCompatActivity  {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // 注销按钮
        Button btnLogout = findViewById(R.id.btnLogout);
        btnLogout.setOnClickListener(v -> {
            SharedPreferences.Editor editor = getSharedPreferences("user_prefs", MODE_PRIVATE).edit();
            editor.remove("is_logged_in");
            editor.apply();

            // 返回登录页
            startActivity(new Intent(this, LoginActivity.class));
            finish();
        });
    }
}