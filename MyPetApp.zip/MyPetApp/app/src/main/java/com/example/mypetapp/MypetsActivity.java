package com.example.mypetapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.TextView;

public class MypetsActivity extends BaseActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_pets);
        setSelectedNavItem(R.id.nav_my_pets);

        // 显示已选宠物
        TextView tvSelectedPet = findViewById(R.id.tvSelectedPet);
        SharedPreferences preferences = getSharedPreferences("MyPetPrefs", MODE_PRIVATE);
        String selectedPet = preferences.getString("selected_pet", "暂无宠物");
        tvSelectedPet.setText("当前宠物：" + selectedPet);

        // 跳转到宠物照片页面
        findViewById(R.id.btnViewPhotos).setOnClickListener(v -> {
            Intent intent = new Intent(this, PetPhotoActivity.class);
            intent.putExtra("pet_name", selectedPet);
            startActivity(intent);
        });

        // 跳转到宠物视频页面
        findViewById(R.id.btnViewVideos).setOnClickListener(v -> {
            Intent intent = new Intent(this, PetVideoActivity.class);
            intent.putExtra("pet_name", selectedPet);
            startActivity(intent);
        });
    }
}