package com.example.mypetapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class PersonalActivity extends BaseActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_personal);
        setSelectedNavItem(R.id.nav_personal); // 设置当前选中项
    }
}