package com.example.mypetapp;

import androidx.appcompat.app.AppCompatActivity;

import android.net.Uri;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.VideoView;

public class PetVideoActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pet_video);

        VideoView videoView = findViewById(R.id.videoView);
        TextView tvVideoDescription = findViewById(R.id.tvVideoDescription);

        String petName = getIntent().getStringExtra("pet_name");

        if (petName.equals("狗狗")) {
            videoView.setVideoURI(Uri.parse("android.resource://" + getPackageName() + "/" + R.raw.dog_video));
            tvVideoDescription.setText("这是一只可爱的狗狗视频！");
        } else {
            videoView.setVideoURI(Uri.parse("android.resource://" + getPackageName() + "/" + R.raw.cat_video));
            tvVideoDescription.setText("这是一只可爱的猫咪视频！");
        }

        videoView.start();
    }
}